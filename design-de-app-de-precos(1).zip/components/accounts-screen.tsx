"use client"

import { ChevronRight, Plus, Wallet } from "lucide-react"
import { getAccountIcon } from "@/lib/icon-map"
import { accountTotalSpent, formatBRL } from "@/lib/price-utils"
import type { Account } from "@/lib/types"
import { TopBar } from "./top-bar"

export function AccountsScreen({
  accounts,
  onOpenAccount,
}: {
  accounts: Account[]
  onOpenAccount: (id: string) => void
}) {
  const hasAccounts = accounts.length > 0
  const total = accounts.reduce((acc, a) => acc + accountTotalSpent(a), 0)

  return (
    <div className="relative flex h-full flex-col">
      <TopBar title="Quanto Paguei?" subtitle="Suas contas de compra" />

      <div className="flex-1 overflow-y-auto">
        {hasAccounts ? (
          <div className="flex flex-col gap-4 p-4 pb-28">
            <div className="rounded-2xl bg-primary p-4 text-primary-foreground">
              <p className="text-sm opacity-90">Total registrado em todas as contas</p>
              <p className="mt-1 text-3xl font-bold tabular-nums">{formatBRL(total)}</p>
            </div>

            <h2 className="px-1 text-sm font-semibold text-foreground">Minhas contas</h2>

            <div className="flex flex-col gap-3">
              {accounts.map((account) => {
                const Icon = getAccountIcon(account.icon)
                const itemCount = account.products.length
                return (
                  <button
                    key={account.id}
                    type="button"
                    onClick={() => onOpenAccount(account.id)}
                    className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-4 text-left transition-colors active:bg-muted"
                  >
                    <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground">
                      <Icon className="size-6" aria-hidden="true" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold leading-tight text-card-foreground">
                        {account.name}
                      </p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {itemCount} {itemCount === 1 ? "produto" : "produtos"}
                      </p>
                    </div>
                    <span className="shrink-0 text-sm font-bold tabular-nums text-card-foreground">
                      {formatBRL(accountTotalSpent(account))}
                    </span>
                    <ChevronRight className="size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
                  </button>
                )
              })}
            </div>
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-5 px-8 text-center">
            <div className="flex size-20 items-center justify-center rounded-3xl bg-accent">
              <Wallet className="size-10 text-primary" aria-hidden="true" />
            </div>
            <div className="space-y-1.5">
              <h2 className="text-balance text-xl font-bold text-foreground">Nenhuma conta ainda</h2>
              <p className="text-pretty text-sm text-muted-foreground">
                Crie contas como “Feira do mês”, “Material escolar” ou “Aniversário” para organizar
                suas compras.
              </p>
            </div>
          </div>
        )}
      </div>

      <button
        type="button"
        aria-label="Nova conta"
        className="absolute bottom-6 right-6 flex h-14 items-center gap-2 rounded-2xl bg-primary px-5 font-semibold text-primary-foreground shadow-lg transition-transform active:scale-95"
      >
        <Plus className="size-6" aria-hidden="true" />
        Nova conta
      </button>
    </div>
  )
}
