"use client"

import { Check, ScanLine } from "lucide-react"
import { useMemo, useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { stores } from "@/lib/mock-data"
import {
  avgPrice,
  formatBRL,
  latestEntry,
  priceLevel,
  usualQuantity,
  variationBetween,
} from "@/lib/price-utils"
import type { Account } from "@/lib/types"
import { PriceLevelBadge } from "./price-level-badge"
import { TopBar } from "./top-bar"
import { VariationBadge } from "./variation-badge"

export function AddEntryScreen({
  account,
  onBack,
  onSave,
}: {
  account: Account
  onBack: () => void
  onSave: () => void
}) {
  const [name, setName] = useState("")
  const [price, setPrice] = useState("")
  const [quantity, setQuantity] = useState("")
  const [store, setStore] = useState(stores[0])

  const parsedPrice = parseFloat(price.replace(",", ".")) || 0

  // Casa com um produto existente da conta para mostrar referências
  const matched = useMemo(() => {
    const n = name.trim().toLowerCase()
    if (!n) return undefined
    return account.products.find((p) => p.name.toLowerCase().includes(n))
  }, [name, account])

  const previousPrice = matched ? latestEntry(matched)?.unitPrice ?? null : null
  const avg = matched ? avgPrice(matched) ?? null : null
  const usual = matched ? usualQuantity(matched) : undefined
  const variation = parsedPrice > 0 ? variationBetween(parsedPrice, previousPrice) : null
  const level = matched && parsedPrice > 0 ? priceLevel(parsedPrice, matched) : null

  const canSave = name.trim().length > 0 && parsedPrice > 0

  return (
    <div className="flex h-full flex-col">
      <TopBar title="Nova compra" subtitle={account.name} onBack={onBack} />

      <div className="flex-1 overflow-y-auto p-4 pb-4">
        <button
          type="button"
          className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-primary/40 bg-accent/40 py-5 font-semibold text-primary transition-colors active:bg-accent"
        >
          <ScanLine className="size-6" aria-hidden="true" />
          Escanear nota fiscal
        </button>

        <div className="my-5 flex items-center gap-3">
          <span className="h-px flex-1 bg-border" />
          <span className="text-xs font-medium text-muted-foreground">ou preencha manualmente</span>
          <span className="h-px flex-1 bg-border" />
        </div>

        <div className="flex flex-col gap-5">
          <div className="space-y-2">
            <Label htmlFor="produto" className="text-sm font-medium">
              Nome do produto
            </Label>
            <Input
              id="produto"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Arroz Branco 5kg"
              className="h-12 rounded-xl bg-card text-base"
            />
            {matched && (
              <p className="text-xs text-muted-foreground">
                Produto encontrado nesta conta — você costuma comprar{" "}
                <span className="font-semibold text-foreground">
                  {usual} {matched.unit}
                </span>
                .
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="valor" className="text-sm font-medium">
                Valor unitário
              </Label>
              <Input
                id="valor"
                inputMode="decimal"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="R$ 0,00"
                className="h-12 rounded-xl bg-card text-base tabular-nums"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="qtd" className="text-sm font-medium">
                Quantidade
              </Label>
              <Input
                id="qtd"
                inputMode="numeric"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder={usual != null ? String(usual) : "1"}
                className="h-12 rounded-xl bg-card text-base tabular-nums"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Estabelecimento</Label>
            <div className="flex flex-wrap gap-2">
              {stores.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setStore(s)}
                  className={
                    "rounded-full border px-4 py-2 text-sm font-medium transition-colors " +
                    (store === s
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-card text-foreground active:bg-muted")
                  }
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Área de referência: caro / barato + variação */}
          <div className="rounded-2xl border border-border bg-card p-4">
            {parsedPrice > 0 ? (
              matched && previousPrice != null ? (
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-sm text-muted-foreground">Comparado ao seu histórico</p>
                    <PriceLevelBadge level={level} />
                  </div>
                  <div className="flex items-center justify-between gap-3 border-t border-border pt-3">
                    <p className="text-sm text-foreground">
                      Última vez{" "}
                      <span className="font-semibold tabular-nums">{formatBRL(previousPrice)}</span>
                      {avg != null && (
                        <>
                          {" • "}média{" "}
                          <span className="font-semibold tabular-nums">{formatBRL(avg)}</span>
                        </>
                      )}
                    </p>
                    <VariationBadge variation={variation} size="md" />
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between gap-3">
                  <p className="text-pretty text-sm text-muted-foreground">
                    Primeiro registro deste produto. As próximas compras mostrarão se está caro ou barato.
                  </p>
                  <VariationBadge variation={null} size="md" />
                </div>
              )
            ) : (
              <p className="text-pretty text-sm text-muted-foreground">
                Informe o valor para ver se está mais caro ou mais barato que antes.
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="border-t border-border bg-card p-4">
        <button
          type="button"
          disabled={!canSave}
          onClick={onSave}
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary text-base font-semibold text-primary-foreground transition-transform active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Check className="size-5" aria-hidden="true" />
          Salvar na compra
        </button>
      </div>
    </div>
  )
}
