import {
  Cake,
  Gift,
  Heart,
  Home,
  type LucideIcon,
  School,
  ShoppingCart,
} from "lucide-react"

export const iconMap: Record<string, LucideIcon> = {
  cart: ShoppingCart,
  school: School,
  cake: Cake,
  home: Home,
  gift: Gift,
  heart: Heart,
}

export function getAccountIcon(key: string): LucideIcon {
  return iconMap[key] ?? ShoppingCart
}
