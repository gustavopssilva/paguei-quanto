import { TrendingDown, TrendingUp, Wallet } from "lucide-react"
import { cn } from "@/lib/utils"
import type { PriceLevel } from "@/lib/price-utils"

const config: Record<
  PriceLevel,
  { label: string; icon: typeof Wallet; className: string }
> = {
  barato: {
    label: "Está barato",
    icon: TrendingDown,
    className: "bg-success/10 text-success",
  },
  medio: {
    label: "Preço na média",
    icon: Wallet,
    className: "bg-muted text-muted-foreground",
  },
  caro: {
    label: "Está caro",
    icon: TrendingUp,
    className: "bg-destructive/10 text-destructive",
  },
}

export function PriceLevelBadge({
  level,
  className,
}: {
  level: PriceLevel | null
  className?: string
}) {
  if (!level) return null
  const { label, icon: Icon, className: variant } = config[level]
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-semibold",
        variant,
        className,
      )}
    >
      <Icon className="size-4" aria-hidden="true" />
      {label}
    </span>
  )
}
