import type { Account } from "./types"

export const accounts: Account[] = [
  {
    id: "feira",
    name: "Feira do mês",
    icon: "cart",
    products: [
      {
        id: "arroz",
        name: "Arroz Branco 5kg",
        unit: "pct",
        history: [
          { id: "a1", date: "2026-01-08", store: "Atacadão", unitPrice: 24.9, quantity: 1 },
          { id: "a2", date: "2026-03-12", store: "Carrefour", unitPrice: 27.5, quantity: 1 },
          { id: "a3", date: "2026-05-20", store: "Pão de Açúcar", unitPrice: 29.9, quantity: 1 },
          { id: "a4", date: "2026-06-10", store: "Atacadão", unitPrice: 26.9, quantity: 2 },
        ],
      },
      {
        id: "leite",
        name: "Leite Integral 1L",
        unit: "un",
        history: [
          { id: "l1", date: "2026-01-08", store: "Atacadão", unitPrice: 5.49, quantity: 6 },
          { id: "l2", date: "2026-03-12", store: "Carrefour", unitPrice: 4.89, quantity: 12 },
          { id: "l3", date: "2026-06-10", store: "Atacadão", unitPrice: 5.99, quantity: 6 },
        ],
      },
      {
        id: "cafe",
        name: "Café Torrado 500g",
        unit: "pct",
        history: [
          { id: "c1", date: "2026-03-12", store: "Carrefour", unitPrice: 18.9, quantity: 1 },
          { id: "c2", date: "2026-05-20", store: "Pão de Açúcar", unitPrice: 21.9, quantity: 2 },
          { id: "c3", date: "2026-06-10", store: "Atacadão", unitPrice: 19.5, quantity: 2 },
        ],
      },
      {
        id: "feijao",
        name: "Feijão Carioca 1kg",
        unit: "pct",
        history: [
          { id: "f1", date: "2026-05-20", store: "Pão de Açúcar", unitPrice: 8.99, quantity: 3 },
          { id: "f2", date: "2026-06-10", store: "Atacadão", unitPrice: 7.49, quantity: 3 },
        ],
      },
    ],
  },
  {
    id: "material-escolar",
    name: "Material escolar",
    icon: "school",
    products: [
      {
        id: "caderno",
        name: "Caderno 10 matérias",
        unit: "un",
        history: [
          { id: "cad1", date: "2025-02-03", store: "Kalunga", unitPrice: 29.9, quantity: 2 },
          { id: "cad2", date: "2026-01-28", store: "Americanas", unitPrice: 32.9, quantity: 2 },
        ],
      },
      {
        id: "caneta",
        name: "Caneta Azul (cx 50)",
        unit: "cx",
        history: [
          { id: "can1", date: "2025-02-03", store: "Kalunga", unitPrice: 39.9, quantity: 1 },
          { id: "can2", date: "2026-01-28", store: "Kalunga", unitPrice: 44.9, quantity: 1 },
        ],
      },
      {
        id: "mochila",
        name: "Mochila Escolar",
        unit: "un",
        history: [{ id: "moc1", date: "2026-01-28", store: "Americanas", unitPrice: 149.9, quantity: 1 }],
      },
    ],
  },
  {
    id: "aniversario",
    name: "Aniversário",
    icon: "cake",
    products: [
      {
        id: "refrigerante",
        name: "Refrigerante 2L",
        unit: "un",
        history: [
          { id: "ref1", date: "2025-09-14", store: "Assaí", unitPrice: 7.99, quantity: 8 },
          { id: "ref2", date: "2026-04-22", store: "Atacadão", unitPrice: 8.49, quantity: 10 },
        ],
      },
      {
        id: "bolo",
        name: "Bolo Confeitado 3kg",
        unit: "un",
        history: [
          { id: "bol1", date: "2025-09-14", store: "Confeitaria Doce", unitPrice: 120, quantity: 1 },
          { id: "bol2", date: "2026-04-22", store: "Confeitaria Doce", unitPrice: 135, quantity: 1 },
        ],
      },
      {
        id: "salgados",
        name: "Salgados (cento)",
        unit: "cento",
        history: [
          { id: "sal1", date: "2025-09-14", store: "Salgaderia", unitPrice: 75, quantity: 3 },
          { id: "sal2", date: "2026-04-22", store: "Salgaderia", unitPrice: 89, quantity: 3 },
        ],
      },
    ],
  },
]

export const stores = ["Atacadão", "Carrefour", "Assaí", "Pão de Açúcar", "Kalunga", "Americanas", "Outro"]

export const accountIcons = ["cart", "school", "cake", "home", "gift", "heart"]
