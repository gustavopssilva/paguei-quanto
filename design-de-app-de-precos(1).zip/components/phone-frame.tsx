import type { ReactNode } from "react"

export function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary p-0 sm:p-6">
      <div className="relative flex h-screen w-full max-w-[420px] flex-col overflow-hidden bg-background shadow-xl sm:h-[860px] sm:rounded-[2.5rem] sm:border-[10px] sm:border-foreground/90">
        {children}
      </div>
    </div>
  )
}
