import { ChevronRight } from "lucide-react"
import type { Product } from "@/lib/types"
import { formatBRL, latestEntry, priceLevel, usualQuantity } from "@/lib/price-utils"
import { VariationBadge } from "./variation-badge"
import { priceVariation } from "@/lib/price-utils"

export function ProductCard({
  product,
  onClick,
}: {
  product: Product
  onClick: () => void
}) {
  const last = latestEntry(product)
  const variation = priceVariation(product)
  const usual = usualQuantity(product)
  const level = last ? priceLevel(last.unitPrice, product) : null

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-4 text-left transition-colors active:bg-muted"
    >
      <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-accent text-base font-bold text-accent-foreground">
        {product.name.charAt(0)}
      </div>

      <div className="min-w-0 flex-1">
        <p className="truncate font-semibold leading-tight text-card-foreground">{product.name}</p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {usual != null ? `Costuma comprar ${usual} ${product.unit}` : last ? last.store : "Sem registros"}
        </p>
      </div>

      <div className="flex shrink-0 flex-col items-end gap-1">
        <span className="text-base font-bold tabular-nums text-card-foreground">
          {last ? formatBRL(last.unitPrice) : "—"}
        </span>
        {level ? (
          <span
            className={
              "rounded-full px-2 py-0.5 text-[11px] font-semibold " +
              (level === "barato"
                ? "bg-success/15 text-success"
                : level === "caro"
                  ? "bg-destructive/15 text-destructive"
                  : "bg-muted text-muted-foreground")
            }
          >
            {level === "barato" ? "Barato" : level === "caro" ? "Caro" : "Na média"}
          </span>
        ) : (
          <VariationBadge variation={variation} />
        )}
      </div>

      <ChevronRight className="size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
    </button>
  )
}
