export type PriceEntry = {
  id: string
  date: string // ISO date
  store: string
  unitPrice: number
  quantity: number
}

export type Product = {
  id: string
  name: string
  unit: string // ex: "kg", "un", "L"
  history: PriceEntry[]
}

export type Account = {
  id: string
  name: string
  icon: string // chave do ícone (ver icon-map)
  products: Product[]
}

/** Uma "compra" derivada: vários itens comprados na mesma data/loja */
export type Purchase = {
  key: string
  date: string
  store: string
  items: { productId: string; productName: string; unit: string; entry: PriceEntry }[]
  total: number
}
