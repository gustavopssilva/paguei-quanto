"use client"

import { useState } from "react"
import { AccountDetailScreen } from "@/components/account-detail-screen"
import { AccountsScreen } from "@/components/accounts-screen"
import { AddEntryScreen } from "@/components/add-entry-screen"
import { PhoneFrame } from "@/components/phone-frame"
import { ProductHistoryScreen } from "@/components/product-history-screen"
import { PurchasesHistoryScreen } from "@/components/purchases-history-screen"
import { accounts } from "@/lib/mock-data"

type Screen =
  | { name: "accounts" }
  | { name: "account"; accountId: string }
  | { name: "purchases"; accountId: string }
  | { name: "add"; accountId: string }
  | { name: "product"; accountId: string; productId: string }

export default function Page() {
  const [screen, setScreen] = useState<Screen>({ name: "accounts" })

  const account =
    "accountId" in screen ? accounts.find((a) => a.id === screen.accountId) : undefined
  const product =
    screen.name === "product" && account
      ? account.products.find((p) => p.id === screen.productId)
      : undefined

  return (
    <PhoneFrame>
      {screen.name === "accounts" && (
        <AccountsScreen
          accounts={accounts}
          onOpenAccount={(id) => setScreen({ name: "account", accountId: id })}
        />
      )}

      {screen.name === "account" && account && (
        <AccountDetailScreen
          account={account}
          onBack={() => setScreen({ name: "accounts" })}
          onOpenProduct={(id) =>
            setScreen({ name: "product", accountId: account.id, productId: id })
          }
          onViewPurchases={() => setScreen({ name: "purchases", accountId: account.id })}
          onNewPurchase={() => setScreen({ name: "add", accountId: account.id })}
        />
      )}

      {screen.name === "purchases" && account && (
        <PurchasesHistoryScreen
          account={account}
          onBack={() => setScreen({ name: "account", accountId: account.id })}
          onOpenProduct={(id) =>
            setScreen({ name: "product", accountId: account.id, productId: id })
          }
        />
      )}

      {screen.name === "add" && account && (
        <AddEntryScreen
          account={account}
          onBack={() => setScreen({ name: "account", accountId: account.id })}
          onSave={() => setScreen({ name: "account", accountId: account.id })}
        />
      )}

      {screen.name === "product" && account && product && (
        <ProductHistoryScreen
          product={product}
          accountName={account.name}
          onBack={() => setScreen({ name: "account", accountId: account.id })}
        />
      )}
    </PhoneFrame>
  )
}
