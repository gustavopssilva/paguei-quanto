import type { Account, PriceEntry, Product, Purchase } from "./types"

export function formatBRL(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
}

export function formatDate(iso: string): string {
  const d = new Date(iso + "T00:00:00")
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" })
}

export function formatShortDate(iso: string): string {
  const d = new Date(iso + "T00:00:00")
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })
}

/** Sorted history, oldest -> newest */
export function sortedHistory(p: Product): PriceEntry[] {
  return [...p.history].sort((a, b) => a.date.localeCompare(b.date))
}

export function latestEntry(p: Product): PriceEntry | undefined {
  return sortedHistory(p).at(-1)
}

export function previousEntry(p: Product): PriceEntry | undefined {
  return sortedHistory(p).at(-2)
}

/** Percentage variation between the last two entries; null if not enough data */
export function priceVariation(p: Product): number | null {
  const last = latestEntry(p)
  const prev = previousEntry(p)
  if (!last || !prev) return null
  return ((last.unitPrice - prev.unitPrice) / prev.unitPrice) * 100
}

export function variationBetween(current: number, previous: number | null): number | null {
  if (previous == null || previous === 0) return null
  return ((current - previous) / previous) * 100
}

export function minPrice(p: Product): number | undefined {
  if (p.history.length === 0) return undefined
  return Math.min(...p.history.map((e) => e.unitPrice))
}

export function maxPrice(p: Product): number | undefined {
  if (p.history.length === 0) return undefined
  return Math.max(...p.history.map((e) => e.unitPrice))
}

export function avgPrice(p: Product): number | undefined {
  if (p.history.length === 0) return undefined
  const sum = p.history.reduce((acc, e) => acc + e.unitPrice, 0)
  return sum / p.history.length
}

/** Quantidade habitualmente comprada (a mais frequente; empate -> a maior) */
export function usualQuantity(p: Product): number | undefined {
  if (p.history.length === 0) return undefined
  const counts = new Map<number, number>()
  for (const e of p.history) counts.set(e.quantity, (counts.get(e.quantity) ?? 0) + 1)
  let best = 0
  let bestCount = 0
  for (const [qty, count] of counts) {
    if (count > bestCount || (count === bestCount && qty > best)) {
      best = qty
      bestCount = count
    }
  }
  return best
}

export type PriceLevel = "barato" | "medio" | "caro"

/**
 * Classifica um valor em relação ao histórico do produto.
 * Usa a média como referência com uma faixa de ~5%.
 */
export function priceLevel(value: number, p: Product): PriceLevel | null {
  const avg = avgPrice(p)
  if (avg == null) return null
  const diff = (value - avg) / avg
  if (diff <= -0.05) return "barato"
  if (diff >= 0.05) return "caro"
  return "medio"
}

/** Agrupa o histórico de todos os produtos de uma conta em "compras" por data+loja */
export function purchasesForAccount(account: Account): Purchase[] {
  const map = new Map<string, Purchase>()
  for (const product of account.products) {
    for (const entry of product.history) {
      const key = `${entry.date}__${entry.store}`
      if (!map.has(key)) {
        map.set(key, { key, date: entry.date, store: entry.store, items: [], total: 0 })
      }
      const purchase = map.get(key)!
      purchase.items.push({
        productId: product.id,
        productName: product.name,
        unit: product.unit,
        entry,
      })
      purchase.total += entry.unitPrice * entry.quantity
    }
  }
  return [...map.values()].sort((a, b) => b.date.localeCompare(a.date))
}

export function accountTotalSpent(account: Account): number {
  return account.products.reduce(
    (acc, p) => acc + p.history.reduce((s, e) => s + e.unitPrice * e.quantity, 0),
    0,
  )
}
