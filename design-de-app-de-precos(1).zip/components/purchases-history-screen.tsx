"use client"

import { History, MapPin } from "lucide-react"
import { formatBRL, formatDate, purchasesForAccount } from "@/lib/price-utils"
import type { Account } from "@/lib/types"
import { TopBar } from "./top-bar"

export function PurchasesHistoryScreen({
  account,
  onBack,
  onOpenProduct,
}: {
  account: Account
  onBack: () => void
  onOpenProduct: (id: string) => void
}) {
  const purchases = purchasesForAccount(account)
  const hasPurchases = purchases.length > 0

  return (
    <div className="flex h-full flex-col">
      <TopBar title="Histórico de compras" subtitle={account.name} onBack={onBack} />

      <div className="flex-1 overflow-y-auto p-4 pb-6">
        {hasPurchases ? (
          <div className="flex flex-col gap-4">
            {purchases.map((purchase) => (
              <div key={purchase.key} className="rounded-2xl border border-border bg-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold text-card-foreground">{formatDate(purchase.date)}</p>
                    <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="size-3.5" aria-hidden="true" />
                      {purchase.store}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Total</p>
                    <p className="text-lg font-bold tabular-nums text-card-foreground">
                      {formatBRL(purchase.total)}
                    </p>
                  </div>
                </div>

                <ul className="mt-3 flex flex-col gap-2 border-t border-border pt-3">
                  {purchase.items.map((item) => (
                    <li key={item.entry.id}>
                      <button
                        type="button"
                        onClick={() => onOpenProduct(item.productId)}
                        className="flex w-full items-center justify-between gap-3 rounded-lg px-1 py-1 text-left transition-colors active:bg-muted"
                      >
                        <span className="min-w-0 flex-1 truncate text-sm text-card-foreground">
                          {item.productName}
                        </span>
                        <span className="shrink-0 text-xs text-muted-foreground tabular-nums">
                          {item.entry.quantity} {item.unit}
                        </span>
                        <span className="shrink-0 text-sm font-semibold tabular-nums text-card-foreground">
                          {formatBRL(item.entry.unitPrice)}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-4 px-8 text-center">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-accent">
              <History className="size-8 text-primary" aria-hidden="true" />
            </div>
            <div className="space-y-1">
              <h2 className="text-lg font-bold text-foreground">Nenhuma compra registrada</h2>
              <p className="text-pretty text-sm text-muted-foreground">
                Quando você registrar uma compra nesta conta, ela aparecerá aqui.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
