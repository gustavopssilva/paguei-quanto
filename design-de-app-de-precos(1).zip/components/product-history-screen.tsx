"use client"

import { ArrowDownCircle, ArrowUpCircle, MapPin, Package, Repeat, Wallet } from "lucide-react"
import {
  avgPrice,
  formatBRL,
  formatDate,
  latestEntry,
  maxPrice,
  minPrice,
  priceLevel,
  sortedHistory,
  usualQuantity,
} from "@/lib/price-utils"
import type { Product } from "@/lib/types"
import { PriceLevelBadge } from "./price-level-badge"
import { VariationBadge } from "./variation-badge"
import { TopBar } from "./top-bar"

export function ProductHistoryScreen({
  product,
  accountName,
  onBack,
}: {
  product: Product
  accountName?: string
  onBack: () => void
}) {
  const entries = sortedHistory(product).reverse() // mais recente primeiro
  const lowest = minPrice(product)
  const highest = maxPrice(product)
  const avg = avgPrice(product)
  const usual = usualQuantity(product)
  const last = latestEntry(product)
  const lastLevel = last ? priceLevel(last.unitPrice, product) : null
  const hasHistory = entries.length > 0

  return (
    <div className="flex h-full flex-col">
      <TopBar title={product.name} subtitle={accountName} onBack={onBack} />

      <div className="flex-1 overflow-y-auto p-4 pb-6">
        {hasHistory ? (
          <>
            {/* Painel de referência de compra */}
            <div className="rounded-2xl border border-border bg-card p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Repeat className="size-3.5" aria-hidden="true" />
                    Costuma comprar
                  </p>
                  <p className="mt-1 text-xl font-bold tabular-nums text-foreground">
                    {usual} <span className="text-sm font-medium text-muted-foreground">{product.unit}</span>
                  </p>
                </div>
                <div>
                  <p className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Wallet className="size-3.5" aria-hidden="true" />
                    Valor de referência
                  </p>
                  <p className="mt-1 text-xl font-bold tabular-nums text-foreground">
                    {avg != null ? formatBRL(avg) : "—"}
                  </p>
                  <p className="text-[11px] text-muted-foreground">média / máx {formatBRL(highest ?? 0)}</p>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between gap-3 border-t border-border pt-4">
                <div>
                  <p className="text-xs text-muted-foreground">Último valor pago</p>
                  <p className="text-lg font-bold tabular-nums text-foreground">
                    {last ? formatBRL(last.unitPrice) : "—"}
                  </p>
                </div>
                <PriceLevelBadge level={lastLevel} />
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-success/30 bg-success/10 p-4">
                <div className="flex items-center gap-1.5 text-success">
                  <ArrowDownCircle className="size-4" aria-hidden="true" />
                  <span className="text-xs font-semibold uppercase tracking-wide">Menor preço</span>
                </div>
                <p className="mt-1.5 text-xl font-bold tabular-nums text-foreground">
                  {lowest != null ? formatBRL(lowest) : "—"}
                </p>
              </div>
              <div className="rounded-2xl border border-destructive/30 bg-destructive/10 p-4">
                <div className="flex items-center gap-1.5 text-destructive">
                  <ArrowUpCircle className="size-4" aria-hidden="true" />
                  <span className="text-xs font-semibold uppercase tracking-wide">Maior preço</span>
                </div>
                <p className="mt-1.5 text-xl font-bold tabular-nums text-foreground">
                  {highest != null ? formatBRL(highest) : "—"}
                </p>
              </div>
            </div>

            <h2 className="mb-3 mt-6 px-1 text-sm font-semibold text-foreground">Linha do tempo</h2>

            <ol className="relative ml-2 border-l-2 border-border">
              {entries.map((entry, index) => {
                const prev = entries[index + 1]?.unitPrice ?? null
                const variation = prev != null ? ((entry.unitPrice - prev) / prev) * 100 : null
                const isLowest = entry.unitPrice === lowest
                const isHighest = entry.unitPrice === highest && lowest !== highest

                return (
                  <li key={entry.id} className="relative ml-5 pb-6 last:pb-0">
                    <span
                      className={
                        "absolute -left-[1.65rem] top-1.5 size-3.5 rounded-full border-2 border-background " +
                        (isLowest ? "bg-success" : isHighest ? "bg-destructive" : "bg-muted-foreground")
                      }
                      aria-hidden="true"
                    />
                    <div className="rounded-2xl border border-border bg-card p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-lg font-bold tabular-nums text-card-foreground">
                            {formatBRL(entry.unitPrice)}
                          </p>
                          <p className="text-xs text-muted-foreground">{formatDate(entry.date)}</p>
                        </div>
                        <VariationBadge variation={variation} />
                      </div>
                      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="size-3.5" aria-hidden="true" />
                          {entry.store}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Package className="size-3.5" aria-hidden="true" />
                          {entry.quantity} {product.unit}
                        </span>
                      </div>
                      {(isLowest || isHighest) && (
                        <span
                          className={
                            "mt-2 inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold " +
                            (isLowest ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive")
                          }
                        >
                          {isLowest ? "Menor preço registrado" : "Maior preço registrado"}
                        </span>
                      )}
                    </div>
                  </li>
                )
              })}
            </ol>
          </>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-4 px-8 text-center">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-accent">
              <Package className="size-8 text-primary" aria-hidden="true" />
            </div>
            <div className="space-y-1">
              <h2 className="text-lg font-bold text-foreground">Sem histórico</h2>
              <p className="text-pretty text-sm text-muted-foreground">
                Este produto ainda não tem preços registrados.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
