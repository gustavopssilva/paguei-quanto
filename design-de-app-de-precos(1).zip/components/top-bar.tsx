import { ArrowLeft } from "lucide-react"
import type { ReactNode } from "react"

export function TopBar({
  title,
  subtitle,
  onBack,
  right,
}: {
  title: string
  subtitle?: string
  onBack?: () => void
  right?: ReactNode
}) {
  return (
    <header className="flex items-center gap-3 border-b border-border bg-card px-4 py-4">
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          aria-label="Voltar"
          className="flex size-10 shrink-0 items-center justify-center rounded-full text-card-foreground transition-colors active:bg-muted"
        >
          <ArrowLeft className="size-5" aria-hidden="true" />
        </button>
      )}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-lg font-bold leading-tight text-card-foreground">{title}</h1>
        {subtitle && <p className="truncate text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      {right}
    </header>
  )
}
