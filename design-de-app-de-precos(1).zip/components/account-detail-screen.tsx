"use client"

import { History, Package, Plus, ShoppingBag } from "lucide-react"
import { getAccountIcon } from "@/lib/icon-map"
import { accountTotalSpent, formatBRL, purchasesForAccount } from "@/lib/price-utils"
import type { Account } from "@/lib/types"
import { ProductCard } from "./product-card"
import { TopBar } from "./top-bar"

export function AccountDetailScreen({
  account,
  onBack,
  onOpenProduct,
  onViewPurchases,
  onNewPurchase,
}: {
  account: Account
  onBack: () => void
  onOpenProduct: (id: string) => void
  onViewPurchases: () => void
  onNewPurchase: () => void
}) {
  const Icon = getAccountIcon(account.icon)
  const purchases = purchasesForAccount(account)
  const hasProducts = account.products.length > 0

  return (
    <div className="flex h-full flex-col">
      <TopBar title={account.name} subtitle={`${account.products.length} produtos`} onBack={onBack} />

      <div className="flex-1 overflow-y-auto p-4 pb-6">
        <div className="flex items-center gap-3 rounded-2xl bg-primary p-4 text-primary-foreground">
          <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary-foreground/15">
            <Icon className="size-6" aria-hidden="true" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm opacity-90">Total registrado</p>
            <p className="text-2xl font-bold tabular-nums">{formatBRL(accountTotalSpent(account))}</p>
          </div>
          <span className="rounded-full bg-primary-foreground/15 px-3 py-1 text-xs font-medium">
            {purchases.length} {purchases.length === 1 ? "compra" : "compras"}
          </span>
        </div>

        {/* Os dois caminhos: histórico ou nova compra */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={onNewPurchase}
            className="flex flex-col items-start gap-2 rounded-2xl bg-primary p-4 text-left text-primary-foreground transition-transform active:scale-[0.98]"
          >
            <Plus className="size-6" aria-hidden="true" />
            <span className="text-sm font-semibold leading-tight">Iniciar nova compra</span>
          </button>
          <button
            type="button"
            onClick={onViewPurchases}
            className="flex flex-col items-start gap-2 rounded-2xl border border-border bg-card p-4 text-left text-card-foreground transition-colors active:bg-muted"
          >
            <History className="size-6 text-primary" aria-hidden="true" />
            <span className="text-sm font-semibold leading-tight">Ver histórico de compras</span>
          </button>
        </div>

        <h2 className="mb-3 mt-6 flex items-center gap-2 px-1 text-sm font-semibold text-foreground">
          <ShoppingBag className="size-4 text-muted-foreground" aria-hidden="true" />
          Itens para referência
        </h2>

        {hasProducts ? (
          <div className="flex flex-col gap-3">
            {account.products.map((product) => (
              <ProductCard key={product.id} product={product} onClick={() => onOpenProduct(product.id)} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-border p-8 text-center">
            <Package className="size-8 text-muted-foreground" aria-hidden="true" />
            <p className="text-pretty text-sm text-muted-foreground">
              Nenhum produto nesta conta ainda. Inicie uma compra para começar a registrar.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
