import { ArrowDown, ArrowUp, Minus } from "lucide-react"
import { cn } from "@/lib/utils"

type Size = "sm" | "md"

export function VariationBadge({
  variation,
  size = "sm",
  className,
}: {
  variation: number | null
  size?: Size
  className?: string
}) {
  if (variation == null) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 rounded-full bg-muted font-medium text-muted-foreground",
          size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-sm",
          className,
        )}
      >
        <Minus className={size === "sm" ? "size-3" : "size-4"} aria-hidden="true" />
        Novo
      </span>
    )
  }

  const isUp = variation > 0.01
  const isDown = variation < -0.01
  const Icon = isUp ? ArrowUp : isDown ? ArrowDown : Minus

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full font-semibold tabular-nums",
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-sm",
        isUp && "bg-destructive/10 text-destructive",
        isDown && "bg-success/10 text-success",
        !isUp && !isDown && "bg-muted text-muted-foreground",
        className,
      )}
      aria-label={isUp ? "Aumento de preço" : isDown ? "Redução de preço" : "Preço estável"}
    >
      <Icon className={size === "sm" ? "size-3" : "size-4"} aria-hidden="true" />
      {isUp ? "+" : ""}
      {variation.toFixed(1).replace(".", ",")}%
    </span>
  )
}
